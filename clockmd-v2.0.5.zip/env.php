<?php
define("AUTH_TOKEN", "17b412a3b49355058e46e6472dd28fe639234972282ff95885c1fb519197a336");
define("API_URL", "https://api.clockwisemd.com/v1");
// define("GROUP_ID", "5558");
// define("GROUP_ID", "415");
// define("GOOGLE_API_KEY", "AIzaSyBcsogO0-zkWtLbn0zgnutfeb40Z92Ndk0");