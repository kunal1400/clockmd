<?php 
echo "<div class='appointments-form-logo'>
  <img src='" . $this->clockwiselogo . "'>
</div>
<div class='appointments-form-header'>
  <h4>" . $hospital['name'] . "</h4>
  <h4>" . $hospital['id'] . "</h4>
  <div class='appointments-address'>
    <a target='_blank' href='//maps.google.com/?q=" . urlencode($hospital['full_address']) . "'><span data-v-4266784e='' role='img' aria-label='MapMarker icon' class='mdi mdi-map-marker'><svg data-v-4266784e='' fill='currentColor' width='24' height='24' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><!----> <path data-v-4266784e='' d='M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z'></path></svg></span>" . $hospital['full_address'] . "</a>
  </div>
  <div class='appointments-tel'>
    <a href='tel:" . $hospital['phone_number'] . "' >" . $hospital['phone_number'] . "</a>
  </div>
</div>
<div class='appointments-form-info'>
  <p>Today's Business Hours: ".$hospital['todays_business_hours']."</p>
  <p>Please complete the following information to hold a place in line! <br>
  Note that all times are estimates only.</p>
</div>";

if ( $hospitalInfoFromDb['ssf_wp_id'] ) {
  $imageUrl = $this->getSsfUploadDir( $hospitalInfoFromDb['ssf_wp_id'] );
  if ( $imageUrl ) {
    echo "<img class='clinic-image' src='".$imageUrl."'/>";
  }
}