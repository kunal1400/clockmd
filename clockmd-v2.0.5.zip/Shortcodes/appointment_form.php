<?php 
echo '<div id="AppointmentFormWrapper" class="">
      <form class="appointments-form" action="" method="post" onsubmit="return getAppointmentData(this)">
          <div class="form-group row">
            <div class="col-md-12">
            <label class="form-check-label">Select a visit reason</label>' . $dropDown . '</div>
          </div>
          <div class="form-group mobrow appointments-visit-time">
            <label class="form-check-label">Patient Type</label>
            <div class="btn-group d-flex js-patientTypeButtonWrapper" role="group" aria-label="Patient Type Button Wrapper">
              <button onclick="updateOption(this)" value="true" type="button" class="btn btn-outline-primary w-100">New Patient</button>
              <button onclick="updateOption(this)" value="false" type="button" class="btn btn-outline-primary w-100 select-option-btn">Existing Patient</button>
            </div>
          </div>
          ' . $timeslots . '
          <div class="form-group row">
            <div class="resmbottom col-sm-12 col-md-6">
              <label class="form-check-label">First Name</label>
                <input required type="text" name="appointment[first_name]" class="form-control">
            </div>
            <div class="col-sm-12 col-md-6">
              <label class="form-check-label">Last Name</label>
                <input required type="text" name="appointment[last_name]" class="form-control">
            </div>
          </div>
          <div class="form-group row">
            <div class="resmbottom col-sm-12 col-md-6">
              <label class="form-check-label">Date of Birth</label>
                <input required type="date" name="appointment[dob]" class="form-control">
            </div>
            <div class="col-sm-12 col-md-6">
              <label class="form-check-label">Patient Birth Sex</label>
              <select required class="form-control form-control-lg" name="appointment[sex]">
                <option value="">Select</option>
                <option value="M">M</option>
                <option value="F">F</option>
              </select>
            </div>
             </div>
          <div class="form-group row">
            <div class="col-sm-12 col-md-12">
              <label class="form-check-label">Cell Phone Number</label>
                <input required type="tel" name="appointment[phone_number]" class="form-control">
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-12 col-md-12">
              <label class="form-check-label">Email</label>
                <input required type="email" name="appointment[email]" class="form-control">
            </div>
          </div>
          <div style="display:none" class="form-group row">
            <div class="col-sm-12 col-md-12">
              <label class="form-check-label">We\'ll send you a text message when it\'s time to show up.</label>
            </div>
            <div class="resmbottom col-sm-12 col-md-4">
              <input min="1" type="number" name="appointment[reminder_minutes]" class="form-control">
            </div>
            <div class="col-sm-12 col-md-8"> minutes before your visit</div>
          </div>
          <div class="form-group row">
            <div class="col-md-12">
              <input type="hidden" name="appointment[can_send_alert_sms]" value="true">
              <input type="hidden" name="appointment[is_new_patient]" />
              <input type="hidden" name="appointment[days_from_today]" />
              <input type="hidden" name="appointment[apt_time]" />
              <button class="btn btn-primary" type="submit">Submit form</button>
            </div>
          </div>
      </form>
    </div>
    <script>
    jQuery(document).ready(function(){
          jQuery("[name=\"appointment[days_from_today]\"]").trigger("click").change()
      var phones = [{ "mask": "(###) ###-####"}];
      jQuery(`input[name="appointment[phone_number]"]`).inputmask({
      mask: phones,
      greedy: false,
      definitions: { "#": { validator: "[0-9]", cardinality: 1}},
            autoUnmask: true
      })
    })
    </script>';