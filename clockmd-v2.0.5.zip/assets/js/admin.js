jQuery(document).ready(function(){
  // https://timepicker.co/demos/
  jQuery('.timepicker').timepicker({
      timeFormat: 'h:mm p',
      // timeFormat: 'HH:mm:ss',
      minTime: new Date(0, 0, 0, 0, 0, 0),
      maxTime: new Date(0, 0, 0, 23, 59, 0),
      startHour: 6,
      startTime: new Date(0, 0, 0, 0, 0, 0),
      interval: 30,
      change: function(time) {
        // the input field
        var element = jQuery(this), text;
        // get access to this Timepicker instance
        var timepicker = element.timepicker();
        text = timepicker.format(time);

        let dataToSend = getDataToSend(this)
        sendData(dataToSend)
      }
  })
})

// /**
// * This is tricky function getting the formdata array and returning
// * the object
// **/
// function convertSerializeArrayToObject( serializeArray ) {
//     var o = {};
//     jQuery.each(serializeArray, function() {
//         if (o[this.name] !== undefined) {
//             if (!o[this.name].push) {
//                 o[this.name] = [o[this.name]];
//             }
//             o[this.name].push(this.value || '');
//         } else {
//             o[this.name] = this.value || '';
//         }
//     });
//     return o;
// }

function saveInAlertNotices(e) {
  let dataToSend = getDataToSend(e)
  sendData(dataToSend)
}

function getDataToSend(element) {
  let parentElement = jQuery(element).closest("tr")
  let data = {
    store_id: jQuery(parentElement).attr("data-storeId"),
    alert_message: jQuery(parentElement).find("[name='alert_message']").val(),
    specific_start_time: jQuery(parentElement).find("[name='specific_start_time']").val(),
    specific_end_time: jQuery(parentElement).find("[name='specific_end_time']").val(),
    enable_all_day_message: false,
    enable_specific_time_message: false
  }

  if ( jQuery(parentElement).find("[name='enable_all_day_message']").is(':checked') ) {
    data.enable_all_day_message = true
  }

  if ( jQuery(parentElement).find("[name='enable_specific_time_message']").is(':checked') ) {
    data.enable_specific_time_message = true
  }

  return data
}

function sendData(dataToSend) {
  jQuery("#alertAdminLoader").show()
  jQuery.ajax({
    url: ajaxurl,
    method: 'POST',
    data: {
      action: 'save_alert_message',
      ...dataToSend
    },
    success: function(response) {
      console.log(response, "response+response")
      jQuery("#alertAdminLoader").hide()
    }
  })

}
