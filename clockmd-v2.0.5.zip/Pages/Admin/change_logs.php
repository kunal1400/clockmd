<h2><i>08-17-2021: </i>Feature <i>Change Logs</i> Implemented - (clockmd-v1.zip) - https://trello.com/c/Mw8wno8N/82-http-cmcbilmartechcom-access</h2>
<b>Files Changed:</b>
<ol>
  <li>clockmd.ph</li>
</ol>
<b>New Files:</b>
<ol>
  <li>Pages/Admin/change_logs.php</li>
</ol>
<hr/>

<h2><i>08-18-2021: </i>Feature <i>Alert Notice With editor</i> (clockmd-v2.zip) </h2>
<b>Files Changed:</b>
<ol>
  <li>clockmd.php</li>
</ol>
<b>New Files:</b>
<ol>
  <li>Pages/Admin/alert_notices_editor.php</li>
</ol>
<hr/>

<h2><i>08-19-2021: </i>Feature <i>Code to Stop COVID testing after 6pm</i> (clockmd-v2.0.1.zip) </h2>
<b>Files Changed:</b>
<ol>
  <li>clockmd.php - added code from line #618 to #623 </li>
</ol>
<hr/>

<h2><i>08-25-2021: </i>Feature <i>Breaking the code into shortcodes</i> (clockmd-v2.0.2.zip) </h2>
<b>Files Changed:</b>
<ol>
  <li>clockmd.php - Breaked the code into Shortcodes </li>
</ol>
<b>New Files:</b>
<ol>
  <li>Shortcodes/appointment_form.php</li>
  <li>Shortcodes/clinic_info.php</li>
</ol>
<b>Shortcodes:</b>
<ol>
  <li><i style="background-color: #8fe28f;font-size: 15px">[clockmd_show_hospitals]</i> To show appointment form</li>
  <li><i style="background-color: #8fe28f;font-size: 15px">[clockmd_clinic_info]</i> To show clinic information</li>
  <li><i style="background-color: #8fe28f;font-size: 15px">[clockmd_alert_message]</i> To show alert messages</li>
</ol>
<hr/>

<h2><i>08-26-2021: </i>New Feature (clockmd-v2.0.5.zip) </h2>
<b>Files Changed:</b>
<ol>
  <li>clinic_info.php - Added Hospital Id on frontend</li>
  <li>alert_notices.php - Added Hospital Id on frontend</li>
  <li>alert_notices_editor.php - Fixed the default message code</li>
  <li>alert_notices_editor.php - New functionality for close clinic</li>
</ol>
<hr/>