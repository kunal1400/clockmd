<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">
  <div id="alertAdminLoader" style="position: fixed;width: 100%;height: 100%;background-color: rgba(0,0,0,0.6);top: 0;bottom: 0;left: 0;right: 0;display:none"></div>
	<h1>Alert Notices</h1>
	<p>These are the alert notices which will show on the published clinics.</p>

	<?php
    if ( is_array($stores) && count($stores) > 0 ) {

      // echo '<table class="widefat">
      // <thead>
      //   <th width="10">#</th>
      //   <th width="100">Store Name</th>
      //   <th>Message To Show</th>
      //   <th width="50">Enable All Day</th>
      //   <th width="50">Enable Specific Time</th>
      //   <th width="100">Specific Time</th>
      // </thead>
      // <tbody>';
      // foreach ($stores as $i => $store) {
      //   /**
      //   * Getting the saved from options table for particular store
      //   **/
      //   // $optionKey   = "#".$store['ssf_wp_id']."_store_alert_notice";
      //   $optionKey   = $this->getOptionKey( $store['ssf_wp_id'] );
      //   $optionValue = get_option($optionKey);
      //   $alert_message = "";
      //   $specific_start_time = "";
      //   $specific_end_time = "";
      //   $enable_all_day_message = false;
      //   $enable_specific_time_message = false;
      //   if ( $optionValue ) {
      //     $storeAlertData = json_decode($optionValue, true);
      //     $alert_message = stripslashes($storeAlertData['alert_message']);
      //     $specific_start_time = $storeAlertData['specific_start_time'];
      //     $specific_end_time = $storeAlertData['specific_end_time'];
      //     $enable_all_day_message = $storeAlertData['enable_all_day_message'];
      //     $enable_specific_time_message = $storeAlertData['enable_specific_time_message'];
      //     // echo '<pre>';
      //     // print_r($storeAlertData);
      //     // var_dump($enable_all_day_message);
      //     // print_r($enable_specific_time_message);
      //     // echo '</pre>';
      //   }

      //   /**
      //   * Generating the style for alternate rows of table
      //   **/
      //   $isPublished = "Published";
      //   if ( $store['ssf_wp_is_published'] != 1 ) {
      //     $isPublished = "Draft";
      //     $style = 'style="background-color:#f7ecec"';
      //     if ( $i%2 == 0 ) {
      //       $style = 'style="background-color:#f7dede"';
      //     }
      //   }
      //   else {
      //     $style = 'style="background-color:#fff"';
      //     if ( $i%2 == 0 ) {
      //       $style = 'style="background-color:#eee"';
      //     }
      //   }

      //   $specificRangeStartTimeId = ($i+1)."specific_range_start_time";
      //   $specificRangeEndTimeId = ($i+1)."specific_range_end_time";

      //   /**
      //   * Rendering the rows of the table
      //   **/
      //   echo '<tr '.$style.' data-storeId="'.$store['ssf_wp_id'].'">
      //       <td>'.($i+1).'</td>
      //       <td>
      //         <a href="'.admin_url( 'admin.php?page=alert_notices&storeId='.$store['ssf_wp_id'] ).'">
      //           '.$store['ssf_wp_store'].'
      //         </a>
      //         <b>('.$isPublished.')</b>
      //       </td>
      //       <td>
      //         <textarea name="alert_message" rows="5" style="width:100%" onblur="saveInAlertNotices(this)">'.$alert_message.'</textarea>
      //       </td>
      //       <td>
      //         <input type="checkbox" '.($enable_all_day_message === "true" ? "checked" : "").' name="enable_all_day_message" onclick="saveInAlertNotices(this)" />
      //       </td>
      //       <td>
      //         <input type="checkbox" '.($enable_specific_time_message === "true" ? "checked" : "").' name="enable_specific_time_message" onclick="saveInAlertNotices(this)" />
      //       </td>
      //       <td>
      //         <p>
      //           <label>Start Time</label>
      //           <input name="specific_start_time" id="'.$specificRangeStartTimeId.'" autocomplete="off" type="text" class="timepicker" onchange="saveInAlertNotices(this)" value="'.$specific_start_time.'"  />
      //         </p>
      //         <p>
      //           <label>End Time</label>
      //           <input name="specific_end_time" id="'.$specificRangeEndTimeId.'" autocomplete="off" type="text" class="timepicker" onchange="saveInAlertNotices(this)" value="'.$specific_end_time.'" />
      //         </p>
      //       </td>
      //   </tr>';
      // }
      // echo '</tbody></table>';
      

      echo '<table class="widefat">
      <thead>
        <th width="10">#</th>
        <th width="">Store Name</th>
        <th width="">Frontend URL</th>
        <th width="50">Enable All Day</th>
        <th width="50">Enable Specific Time</th>
        <th width="50">Start Time</th>
        <th width="50">End Time</th>
      </thead>
      <tbody>';
      foreach ($stores as $i => $store) {
        /**
        * Getting the saved from options table for particular store
        **/
        // $optionKey   = "#".$store['ssf_wp_id']."_store_alert_notice";
        $optionKey   = $this->getOptionKey( $store['ssf_wp_id'] );
        $optionValue = get_option($optionKey);
        $alert_message = "";
        $specific_start_time = "";
        $specific_end_time = "";
        $enable_all_day_message = false;
        $enable_specific_time_message = false;
        if ( $optionValue ) {
          $storeAlertData = json_decode($optionValue, true);
          $alert_message = stripslashes($storeAlertData['alert_message']);
          $specific_start_time = $storeAlertData['specific_start_time'];
          $specific_end_time = $storeAlertData['specific_end_time'];
          $enable_all_day_message = $storeAlertData['enable_all_day_message'];
          $enable_specific_time_message = $storeAlertData['enable_specific_time_message'];
        }

        /**
        * Generating the style for alternate rows of table
        **/
        $isPublished = "Published";
        if ( $store['ssf_wp_is_published'] != 1 ) {
          $isPublished = "Draft";
          $style = 'style="background-color:#f7ecec"';
          if ( $i%2 == 0 ) {
            $style = 'style="background-color:#f7dede"';
          }
        }
        else {
          $style = 'style="background-color:#fff"';
          if ( $i%2 == 0 ) {
            $style = 'style="background-color:#eee"';
          }
        }

        $specificRangeStartTimeId = ($i+1)."specific_range_start_time";
        $specificRangeEndTimeId = ($i+1)."specific_range_end_time";

        /**
        * Rendering the rows of the table
        **/
        echo '<tr '.$style.' data-storeId="'.$store['ssf_wp_id'].'">
            <td>'.($i+1).'</td>            
            <td>
              <a href="'.admin_url( 'admin.php?page=alert_notices&storeId='.$store['ssf_wp_id'] ).'">
                '.$store['ssf_wp_store'].'
              </a>
              <b>('.$isPublished.')</b>
            </td>
            <td><a href="'.$store['ssf_wp_ext_url'].'" target="_blank"/>'.$store['ssf_wp_ext_url'].'</a></td>            
            <td>'.($enable_all_day_message === "true" ? "yes" : "no").'</td>
            <td>'.($enable_specific_time_message === "true" ? "yes" : "no").'</td>
            <td>'.$specific_start_time.'</td>
            <td>'.$specific_end_time.'</td>
        </tr>';
      }
      echo '</tbody></table>';
    
    }
    else {
      echo "<p>No store found</p>";
    }
	?>
</div>
