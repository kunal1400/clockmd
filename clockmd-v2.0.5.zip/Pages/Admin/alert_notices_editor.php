<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">
	<?php
$storeId = $_GET['storeId'];
if (is_array($stores) && count($stores) > 0)
{
    foreach ($stores as $i => $store)
    {
        if ($storeId !== $store['ssf_wp_id'])
        {
            continue;
        }

        /**
         * Getting the saved from options table for particular store
         *
         */
        // $optionKey   = "#".$store['ssf_wp_id']."_store_alert_notice";
        $optionKey = $this->getOptionKey($store['ssf_wp_id']);
        $optionValue = get_option($optionKey);
        $alert_message = "";
        $no_time_slot_message = $this->noTimeSlotMessage;
        $specific_start_time = "";
        $specific_end_time = "";
        $enable_all_day_message = false;
        $enable_specific_time_message = false;
        $is_clinic_closed = false;
        if ($optionValue)
        {
            $storeAlertData = json_decode($optionValue, true);
            $alert_message = stripslashes($storeAlertData['alert_message']);
            $specific_start_time = $storeAlertData['specific_start_time'];
            $specific_end_time = $storeAlertData['specific_end_time'];
            $enable_all_day_message = $storeAlertData['enable_all_day_message'];
            $enable_specific_time_message = $storeAlertData['enable_specific_time_message'];
            $is_clinic_closed = $storeAlertData['is_clinic_closed'];
            if ( !empty($storeAlertData['no_time_slot_message']) ) {
						  $no_time_slot_message = $storeAlertData['no_time_slot_message'];
            }
        }        

        $specificRangeStartTimeId = ($i + 1) . "specific_range_start_time";
        $specificRangeEndTimeId = ($i + 1) . "specific_range_end_time";

        /**
         * Rendering the rows of the table
         *
         */
        $editor_id = '_woorevo_pro_catext_shop_content_top';
?>
<form action="" method="post">
				<table class="form-table">
					<tbody>
        <tr class="form-field form-required">
          <td colspan="3" align="center"><h2><?php echo $store['ssf_wp_store'] ?></h2></td>
        </tr>
        <tr class="form-field form-required">
          <th scope="row" valign="top">
            <b>Message To Show</b>
          </th>
          <td colspan="2">
            <?php
						wp_editor($alert_message, $editor_id, array(
							'textarea_name' => 'alert_message',
							'editor_height' => 150,
							'media_buttons' => false
						))
						?>
          </td>
        </tr>
        <tr class="form-field form-required">
          <th scope="row" valign="top">
            <b>No Time Slot Message</b>
          </th>
          <td colspan="2">
            <?php
						wp_editor($no_time_slot_message, 'no_time_slot_message_editor', array(
		            'textarea_name' => 'no_time_slot_message',
		            'editor_height' => 150,
		            'media_buttons' => false
		        ))
						?>
          </td>
        </tr>
        <tr class="form-field form-required">
          <th scope="row" valign="top">
            <b>Enable All Day</b>
          </th>
          <td colspan="2">
            <input type="checkbox" <?php echo ($enable_all_day_message === "true" ? "checked" : "") ?> name="enable_all_day_message" />
          </td>
        </tr>
        <tr class="form-field form-required">
          <th scope="row" valign="top">
            <b>Enable Specific Time</b>
          </th>
          <td colspan="2">
            <input type="checkbox" <?php echo ($enable_specific_time_message === "true" ? "checked" : "") ?> name="enable_specific_time_message" />
          </td>
        </tr>
        <tr class="form-field form-required">
          <th scope="row" valign="top">
            <b>Specific Time</b>
          </th>
          <td>
              <label>Start Time</label>
              <input name="specific_start_time" id="<?php echo $specificRangeStartTimeId ?>" autocomplete="off" type="text" class="timepicker regular-text" value="<?php echo $specific_start_time ?>"  />
          </td>
          <td>
              <label>End Time</label>
              <input name="specific_end_time" id="<?php echo $specificRangeEndTimeId ?>" autocomplete="off" type="text" class="timepicker regular-text" value="<?php echo $specific_end_time ?>" />
          </td>
        </tr>
        <tr class="form-field form-required">
          <th scope="row" valign="top">
            <b>Close Clinic</b>
          </th>
          <td colspan="2">
            <input type="checkbox" <?php echo ($is_clinic_closed === "true" ? "checked" : "") ?> name="is_clinic_closed" />
          </td>
        </tr>
				<tr>
					<td colspan="2">
						<input type="hidden" name="update_alert_notices" value="yes" />
						<input type="hidden" name="store_id" value="<?php echo $storeId ?>" />
						<input type="submit" class="button button-primary" />
					</td>
				</tr>
				</tbody>
			</table>
		</form>
      <?php
    }
}
else
{
    echo "<p>No store found</p>";
}
?>
</div>
